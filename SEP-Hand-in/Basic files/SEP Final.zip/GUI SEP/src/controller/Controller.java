package controller;

public interface Controller
{
   void execute(String what) throws Exception;
}
